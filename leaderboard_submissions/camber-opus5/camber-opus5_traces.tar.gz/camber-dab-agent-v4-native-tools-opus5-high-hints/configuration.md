# Camber + Claude Opus 5

- Agent: native Camber Coding Agent + persisted DAB Data Analyst
- Conversation call path: direct AI Platform; no Service Platform conversation created
- Agent configuration: persisted in Service Platform and passed as `preferred_agent`
- Agent tools: native Camber tools only
- Model: `bedrock:claude-opus-5`
- Effort: `high`
- Official DAB hints: yes
- DAB-tuned prompt: yes
- History: empty; every trial uses fresh identifiers
- Concurrent trials: 10
- Runs per query: 5
